package com.example.weather6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Weather6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
