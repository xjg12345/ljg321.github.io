package com.ljg.ganggangweather.net.nettxAPI;

public interface CallBackTXAPT {
    void onSuccess(String result);
    void onError(Exception e);
}
