package com.ljg.ganggangweather.net.netlocal;

public interface CallBack {
    void onSuccess(String result);
    void onError(Exception e);
}
